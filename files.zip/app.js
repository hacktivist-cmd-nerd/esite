// Toggle dark mode
document.getElementById('darkModeToggle').addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
  localStorage.setItem('darkMode', document.body.classList.contains('dark-mode'));
});

// Persist dark mode preference
if (localStorage.getItem('darkMode') === 'true') {
  document.body.classList.add('dark-mode');
}

// Load JSON data
async function loadJSON(file) {
  const res = await fetch(file);
  return res.json();
}

// Render portfolio carousel if section exists
if (document.getElementById('portfolio-carousel')) {
  loadJSON('data.json').then(data => {
    const portfolioEl = document.getElementById('portfolio-carousel');
    data.portfolio.forEach(item => {
      const div = document.createElement('div');
      div.className = 'carousel-item';
      div.innerHTML = `
        <img src="${item.image}" alt="${item.title}" loading="lazy" />
        <div class="desc">
          <h3>${item.title}</h3>
          <p>${item.description}</p>
        </div>
      `;
      portfolioEl.appendChild(div);
    });
  });
}

// Render services accordion if section exists
if (document.getElementById('services-list')) {
  loadJSON('data.json').then(data => {
    const servicesEl = document.getElementById('services-list');
    data.services.forEach((service, idx) => {
      const item = document.createElement('div');
      item.className = 'accordion-item';
      item.innerHTML = `
        <button class="accordion-title" aria-expanded="false" aria-controls="service-content-${idx}" id="service-title-${idx}">
          ${service.title}
        </button>
        <div class="accordion-content" id="service-content-${idx}" aria-labelledby="service-title-${idx}">
          ${service.description}
        </div>
      `;
      servicesEl.appendChild(item);
    });

    // Accordion interactive
    servicesEl.querySelectorAll('.accordion-title').forEach(btn => {
      btn.addEventListener('click', function () {
        servicesEl.querySelectorAll('.accordion-item').forEach(i => i.classList.remove('active'));
        btn.parentElement.classList.toggle('active');
        // Accessibility
        servicesEl.querySelectorAll('.accordion-title').forEach(b => b.setAttribute('aria-expanded', 'false'));
        btn.setAttribute('aria-expanded', btn.parentElement.classList.contains('active'));
      });
    });
  });
}

// Render testimonials if section exists
if (document.getElementById('testimonials-list')) {
  loadJSON('data.json').then(data => {
    const testimonialEl = document.getElementById('testimonials-list');
    data.testimonials.forEach(t => {
      const div = document.createElement('div');
      div.className = 'carousel-item';
      div.innerHTML = `
        <div class="desc">
          <blockquote>"${t.text}"</blockquote>
          <p><strong>- ${t.author}</strong>, ${t.role}</p>
        </div>
      `;
      testimonialEl.appendChild(div);
    });
  });
}

// Contact form handling
if (document.getElementById('contactForm')) {
  document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Thank you for your inquiry! We will get back to you soon.');
    this.reset();
  });
}